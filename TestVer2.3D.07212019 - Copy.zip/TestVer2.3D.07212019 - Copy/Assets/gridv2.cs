﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class gridv2 : MonoBehaviour
{ 
    public int xSize, ySize, zSize;
    public int cubeScale = 5;
    public Vector3[] unitPlaneXY, unitPlaneYZ, unitPlaneXZ;
    public int xComp, yComp, zComp;
    public GameObject unitCube;
    public GameObject unitPointXY;
    public GameObject unitPointYZ;
    public GameObject unitPointXZ;

    private Text componentsText;    
    private int _unitLength;
    private Vector3[] _gridScale;
    private Vector3[][] _unitPlanes;
    private List<Transform> _instance = new List<Transform>();

    // Start is called before the first frame update
    private void Awake()
    {
        Font Arial;
        Arial = (Font)Resources.GetBuiltinResource(typeof(Font), "Arial.ttf");

        //Create Canvas and set as child to UnitCube GameObject
        GameObject canvasCube = new GameObject();
        canvasCube.transform.SetParent(unitCube.transform, true);
        canvasCube.name = "Canvas Cube";
        canvasCube.AddComponent<Canvas>();
        canvasCube.AddComponent<CanvasScaler>();

        //Create text GameObject
        GameObject textCube = new GameObject();
        textCube.transform.SetParent(canvasCube.transform, true);
        textCube.AddComponent<Text>();

        //text properties
        componentsText = textCube.GetComponent<Text>();
        componentsText.font = Arial;
        componentsText.fontSize = 48;
        componentsText.GetComponent<Transform>().localScale = new Vector3(.005f, .005f, .005f);
        componentsText.alignment = TextAnchor.UpperCenter;
        componentsText.GetComponent<Transform>().position = new Vector3(0, .2f, 0);

        RectTransform rectTransform;
        rectTransform = componentsText.GetComponent<RectTransform>();
        rectTransform.sizeDelta = new Vector2(500, 100);


    }
    void Start()
    {
        _unitLength = zSize;
        CreateUnitPlane();
        Debug.Log(_unitPlanes);

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            StartCoroutine(DrawUnitPlaneRoutine());
        }

        if (Input.GetKeyDown(KeyCode.C))
        {
            
            unitCube.GetComponent<Transform>().localScale = new Vector3(cubeScale, cubeScale, cubeScale);
            unitCube.GetComponent<Transform>().position = new Vector3(xComp,yComp,zComp);
            componentsText.text = "(" + xComp + "," + yComp + "," + zComp + ")";
        }
    }

    //private void awake()
    //{
    //    createunitplane();
    //}
    private void CreateUnitPlane()
    {
        unitPlaneXY = new Vector3[(xSize + 1) * (ySize + 1)];
        unitPlaneYZ = new Vector3[(ySize + 1) * (zSize + 1)];
        unitPlaneXZ = new Vector3[(xSize + 1) * (zSize + 1)];

        for (int i = 0, x = 0; x <= xSize; x++)
        {
            for (int y = 0; y <= ySize; y++, i++)
            {
                unitPlaneXY[i] = new Vector3((x -(_unitLength/2)),(y - (_unitLength/2)),0);
                unitPointXY.GetComponent<Transform>().localScale = new Vector3(.01f, .01f, _unitLength);
            }
        }

        for (int j = 0, y = 0; y <= ySize; y++)
        {
            for (int z = 0; z <= zSize; z++, j++)
            {
                unitPlaneYZ[j] = new Vector3(0,(y -( _unitLength/2)),(z-( _unitLength/2)));
                unitPointYZ.GetComponent<Transform>().localScale = new Vector3(_unitLength, .01f, .01f);
            }
        }

        for (int k = 0, x = 0; x <= xSize; x++)
        {
            for (int z = 0; z <= zSize; z++, k++)
            {
                unitPlaneXZ[k] = new Vector3((x-(_unitLength/2)), 0, (z-(_unitLength/2)));
                unitPointXZ.GetComponent<Transform>().localScale = new Vector3(.01f, _unitLength, .01f);

            }
        }

    }

    IEnumerator DrawUnitPlaneRoutine()
    {
        while (true)
        {
            for (int i = 0; i < unitPlaneXY.Length; i++)
            {
                yield return new WaitForSeconds(.0001f);
                Instantiate(unitPointXY, unitPlaneXY[i], Quaternion.identity);
                Instantiate(unitPointYZ, unitPlaneYZ[i], Quaternion.identity);
                Instantiate(unitPointXZ, unitPlaneXZ[i], Quaternion.identity);

            }
        }
    }
}

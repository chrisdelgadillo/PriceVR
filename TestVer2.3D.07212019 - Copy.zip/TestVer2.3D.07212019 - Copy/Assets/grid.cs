﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(MeshFilter), typeof(MeshRenderer))]
public class grid : MonoBehaviour
{
    public int xSize = 5, ySize = 5, zSize = 5;
    public Vector3[] unit;
    public GameObject unitPoint;

    private List<Transform> _instance = new List<Transform>();
  
    // Start is called before the first frame update
    void Start()
    {
        int instanceCount = (xSize * ySize * zSize);
        CreateUnit();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            StartCoroutine(DrawUnitsRoutine());
        }
    }
    /*private void awake()
    {
        createunit();
    }*/

    private void CreateUnit()
    {
        unit = new Vector3[(xSize + 1) * (ySize + 1)*(zSize + 1)];
        for (int i = 0, x = 0; x <= xSize; x++)
        {
            for (int y = 0; y <= ySize; y++)
            {
                for (int z = 0; z <= zSize; z++, i++)
                {
                    unit[i] = new Vector3(x, y, z);
                }
               
            }
        }
    }

    IEnumerator DrawUnitsRoutine()
    {
        while (true)
        {
            for (int j = 0; j < unit.Length; j++)
            {
                yield return new WaitForSeconds(1.0f);
                Instantiate(unitPoint, unit[j], Quaternion.identity);
            }
        }
    }
    /*private void ondrawgizmos()
    {
        if (unit == null)
            return;
        else
        {
            gizmos.color = color.black;
            for (int i = 0; i <= unit.length; i++)
            {
                gizmos.drawsphere(unit[i], 0.1f);
            }
        }
    }*/
}

